function RC=Bp(RC)

RCtmp=B(B(B(RC)))
RC = RCtmp
end