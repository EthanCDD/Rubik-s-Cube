function twoDcube

global RC
RC = zeros(9,12);
RC(4:6,1:3)=1;
RC(4:6,4:6)=2;
RC(4:6,7:9)=3;
RC(4:6,10:12)=4;
RC(1:3,4:6)=5;
RC(7:9,4:6)=6;
RC(RC==0)=NaN;
end