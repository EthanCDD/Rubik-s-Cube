function RC=Mp(RC)
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here
RCtmp=M(M(M(RC)))
RC = RCtmp
end
