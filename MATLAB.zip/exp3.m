function exp3

end