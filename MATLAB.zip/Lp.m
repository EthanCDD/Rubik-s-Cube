function RC=Lp(RC)
RCtmp=L(L(L(RC)))
RC = RCtmp
end
