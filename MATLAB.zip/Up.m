function RC=Up(RC)
RCtmp=U(U(U(RC)))
RC = RCtmp
end