function RC=Rp(RC)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here


RCtmp=R(R(R(RC)))
RC = RCtmp
end