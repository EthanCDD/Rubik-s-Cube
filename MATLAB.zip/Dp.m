function RC=Dp(RC)

RCtmp=D(D(D(RC)))
RC = RCtmp
end