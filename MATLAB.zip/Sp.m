function RC=Sp(RC)

RCtmp=S(S(S(RC)))
RC = RCtmp
end