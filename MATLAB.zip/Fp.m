function RC=Fp(RC)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here


RCtmp=F(F(F(RC)))
RC = RCtmp
end
